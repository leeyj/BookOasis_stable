---
title: "도서 상세 목록 그리드 뷰 undefined 렌더링 버그"
date: 2026-07-28
category: bugfix
tags: [frontend, detail_render, grid_view]
impact: high
status: fixed
---

# 버그 내역: 도서 상세 목록 그리드 뷰 `undefined` 표시

## 문제 현상
도서 상세 화면에서 그리드 보기 모드를 활성화하면 도서 목록 위치에 `undefined` 텍스트가 표시되고 실제 도서 카드가 렌더링되지 않았음.

## 영향도
- **심각도**: High (그리드 뷰 기능 전체 미동작)
- **영향 범위**: 도서 상세 화면 (`library_detail.html`) 그리드 보기 모드 전체
- **원인 파일**: `static/js/detail_render.js`

## 원인 분석
`renderVolumesList()` 함수 내 `if (gridMode)` 분기에서 `orderedBooks.forEach()` 루프로
`volumesHtml` 문자열을 쌓은 뒤 **`return` 구문이 누락**되어 있었음.

```js
// 수정 전 (버그)
if (gridMode) {
    orderedBooks.forEach(b => {
        volumesHtml += `...`;
    });
    // ← return 없음! → 함수가 undefined 반환
} else {
    // 리스트 모드는 return 있음
    return `...`;
}
```

리스트 모드(`else` 블록)에는 `return` 구문이 있었지만, 그리드 모드 분기에는 빠져 있었기 때문에 JavaScript 함수가 암묵적으로 `undefined`를 반환했고, 호출부에서 이를 DOM에 직접 삽입하면서 `"undefined"` 문자열이 화면에 노출됨.

또한 그리드 컨테이너 클래스를 `volumes-grid`로 잘못 명명하여 CSS(`volumes-list-grid`)와 불일치하는 문제도 함께 수정.

## 수정 사항

### `static/js/detail_render.js`
- `if (gridMode)` 블록 내 `orderedBooks.forEach()` 루프 직후 `return` 구문 추가
- 반환하는 HTML 구조는 리스트 모드와 동일하게 `volumes-section` > 툴바 + 그리드 컨테이너 구성
- 그리드 컨테이너 클래스를 `volumes-grid` → `volumes-list-grid`로 수정 (CSS 정의와 일치)

## 해결 확인
- `node --check static/js/detail_render.js` → exit 0 (구문 오류 없음)
- 그리드 뷰 활성화 시 `undefined` 대신 도서 카드 그리드가 정상 렌더링
- 정렬(오래된순/최신순) 및 미열람 필터 버튼 정상 표시
