---
title: "kavita.yaml Summary 멀티라인 스킵 및 꺾쇠 표현 삭제 버그"
date: 2026-07-28
category: bugfix
tags: [scanner, yaml, kavita_yaml, metadata, summary]
impact: high
status: fixed
---

# 버그 내역: kavita.yaml Summary 멀티라인 스킵 및 꺾쇠 표현 삭제

## 문제 현상
1. kavita.yaml `Summary` 필드에 빈 줄(단락 구분)이 있을 때 **첫 번째 단락(줄)만 저장**되고 나머지가 스킵됨
2. `<알타이어 입문>` 같은 꺾쇠 괄호 표현이 HTML 태그로 오인되어 **텍스트가 통째로 삭제**됨

## 원인 분석

### 버그 1: Summary 멀티라인 스킵

**kavita.yaml 파일 형태 (문제가 되는 케이스):**
```yaml
Name: '한국어의 기원(한길 김승곤 전집 12)'
    Person Publisher: (주)글로벌콘텐츠    ← 4칸 들여쓰기
    Person Writers: 김승곤
    Summary: '알타이어로 추정되는 한국어
                                         ← 빈 줄
        알타이어에 관한 연구가...'         ← 8칸 들여쓰기
```

일부 kavita.yaml 생성 도구가 **두 번째 줄부터 4칸 들여쓰기**를 넣습니다. 이 경우:
- 표준 YAML 파서(`yaml.load`) → **파싱 실패** (block mapping 오류)
- Regex Fallback Parser 동작 → 줄 단위로 처리 → **Summary 키 줄의 첫 값만 캡처**

### 버그 2: 꺾쇠 표현 삭제

`clean_html_tags()`에서 사용하는 정규식:
```python
HTML_TAG_RE = re.compile(r'<[^>]*>')  # 모든 <...> 매칭
```
`<알타이어 입문>`, `<기기만요노 죠셍고>` 등 한국어 꺾쇠 표현도 HTML 태그로 인식하여 제거됨.

## 수정 사항

### `tools/scanner/metadata/kavita_yaml.py`

**① HTML 정규식 수정** (한국어 꺾쇠 보호):
```python
# 수정 전
HTML_TAG_RE = re.compile(r'<[^>]*>')
# 수정 후 — 알파벳/슬래시/!로 시작하는 실제 HTML 태그만 매칭
HTML_TAG_RE = re.compile(r'<[a-zA-Z/!][^>]*>')
```

**② 들여쓰기 보정 로직 추가** (파싱 단계 1-b):
- 원본 파싱 실패 시, 두 번째 줄 이후의 공통 들여쓰기(min_indent)를 계산
- 첫 번째 줄은 그대로 유지하고, 두 번째 줄부터 min_indent만큼 제거 후 재파싱

## 검증 결과
- 들여쓰기 있는 4칸 YAML → Summary **364자 정상 파싱** (이전: 15자)
- `<알타이어 입문>` 꺾쇠 표현 → **보존됨**
- 경고(parser_warnings) → **없음** (정상 파싱 경로 진입)
