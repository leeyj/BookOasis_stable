---
title: "신규 추가 도서 사용자 권한 무시 노출 버그 수정"
category: "bugfix"
date: 2026-07-28
severity: "high"
affected_files:
  - "services/reading_history_service.py"
  - "repositories/sqlite/reading_progress_repository.py"
tags: [permission, recently-added, dashboard, user_category_permissions]
---

# 신규 추가 도서 사용자 권한 무시 노출 버그 수정

## 1. 버그 내용

대시보드 홈 화면의 **"최신 추가 도서"** 섹션(`/api/media/recently-added`)이 사용자의 카테고리 접근 권한과 무관하게 모든 카테고리의 도서를 노출하는 버그.

## 2. 영향도

- **심각도**: HIGH
- **범위**: 일반 유저에게 접근 권한이 없는 카테고리(library)의 신규 도서가 대시보드에 노출됨
- **경로**: `GET /api/media/recently-added?type=general`

## 3. 원인 분석

**`services/reading_history_service.py` — `get_recently_added()` (수정 전 110번 줄)**

```python
# 버그 코드
if user_id and role != 'admin':
    rows = ReadingProgressRepository.fetch_recently_added_by_user(db_type, user_id)
else:
    rows = ReadingProgressRepository.fetch_recently_added_all(db_type, user_id)  # ← 권한 무시 전체 조회
```

조건 `user_id and role != 'admin'`이 False가 되는 케이스:

| 케이스 | 조건 결과 | 실제 동작 | 올바른 동작 |
|--------|-----------|-----------|-------------|
| `user_id=None`, `role=None` | False | `fetch_all()` → **권한 무시** ❌ | 빈 목록 반환 |
| `user_id=존재`, `role='admin'` | False | `fetch_all()` → 전체 조회 ✅ | 동일 |
| `user_id=존재`, `role='user'` | True | `fetch_by_user()` → 권한 필터 ✅ | 동일 |

`user_id`가 `None`(세션 만료, 예외 상황)이면 `else` 브랜치로 분기되어 권한 체크 없이 전체 조회가 실행됨.

## 4. 수정 사항

### [services/reading_history_service.py](file:///c:/project/media_server/services/reading_history_service.py)

분기 조건을 뒤집어 `role == 'admin'`만 전체 조회, 나머지는 항상 권한 필터 쿼리 사용:

```python
# 수정 후
if role == 'admin':
    # 관리자: 전체 카테고리 도서 조회
    rows = ReadingProgressRepository.fetch_recently_added_all(db_type, user_id)
else:
    # 일반 유저 또는 user_id=None: 권한 있는 카테고리만 조회
    # user_id=None이면 user_category_permissions JOIN 매칭 없음 → 빈 목록 반환
    rows = ReadingProgressRepository.fetch_recently_added_by_user(db_type, user_id)
```

### [repositories/sqlite/reading_progress_repository.py](file:///c:/project/media_server/repositories/sqlite/reading_progress_repository.py)

`fetch_recently_added_by_user()`에 `user_id=None` 방어 처리 추가:

```python
# user_id=None 이면 매칭 불가한 값(-1)으로 치환 → 권한 행 없음 → 빈 결과
safe_user_id = int(user_id) if user_id is not None else -1
```

`user_category_permissions` 테이블에 `user_id = -1`인 행은 존재하지 않으므로 `JOIN` 결과가 빈 집합이 되어 SQL TypeError 없이 안전하게 빈 목록 반환.

## 5. 해결 결과

| 케이스 | 수정 전 | 수정 후 |
|--------|---------|---------|
| 관리자 | 전체 조회 ✅ | 전체 조회 ✅ |
| 권한 있는 일반 유저 | 권한 필터 ✅ | 권한 필터 ✅ |
| 권한 없는 일반 유저 | **전체 노출** ❌ | 권한 있는 카테고리만 ✅ |
| user_id=None | **전체 노출** ❌ | 빈 목록 반환 ✅ |
