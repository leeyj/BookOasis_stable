---
title: "RTL 2장 보기 모드 마지막 페이지 다음 권 넘기기 미동작"
date: 2026-07-28
category: bugfix
tags: [viewer, navigation, rtl, 2page, next_episode]
impact: medium
status: fixed
---

# 버그 내역: RTL 2장 보기 마지막 페이지에서 다음 권 넘기기 안 됨

## 문제 현상
만화 뷰어에서 **2장 보기** 모드 + **진행방향 왼쪽(RTL)** 설정 시,
마지막 화면(마지막 두 페이지가 표시된 상태)에서 다음 페이지로 이동해도
다음 권으로 넘어가지 않고 한 페이지 더 이동 후 멈춤.

## 원인 분석

### 페이지 인덱스 구조 (RTL 2장 보기)

`renderer.js`의 `getComicDisplayPageIndex(basePage)`:
```
RTL 모드: displayPage = min(basePage + 1, totalPages - 1)
```

즉 내부 `comicCurrentPage = N`일 때 화면에는 `[N+1, N]` 두 페이지가 표시됨.

### 마지막 화면 시나리오 (총 10페이지 예시)

| comicCurrentPage | 화면(RTL) | 실제 마지막? |
|---|---|---|
| 0 | [1, 0] | No |
| 2 | [3, 2] | No |
| 8 | [9, 8] | **Yes** |
| 9 | [9] | Yes |

`comicCurrentPage = 8`일 때 9번, 8번 페이지가 이미 화면에 표시 → 마지막 화면

### 버그가 발생하는 흐름

`nextComicPage()` (수정 전):
```js
const step = 2;  // 2장 보기
const nextPage = Math.min(8 + 2, 9) = 9;
if (8 < 9 && 9 !== 8) → true → 페이지 9로 이동 (다음 권 발동 안 됨!)
```

`comicCurrentPage = 9`일 때 다시 next:
```js
const nextPage = Math.min(9 + 2, 9) = 9;
if (9 < 9) → false → 다음 권 발동
```

→ **한 번 더 탭해야만 다음 권으로 넘어감** (두 번 클릭 필요)

## 수정 사항

### `static/js/viewer/navigation.js`

`nextComicPage()` 내 RTL 2장 보기 전용 마지막 화면 판별 로직 추가:

```js
const isRtlTwoPage = (step === 2) && Settings.getComicReadingDirection() === 'rtl';
if (isRtlTwoPage) {
  const displayPage = Math.min(currentPage + 1, totalPages - 1);
  if (displayPage >= totalPages - 1) {
    // 이미 displayPage가 마지막 → 다음 권으로 바로 이동
    import('../viewer_next_episode.js').then(m => m.handleNextEpisode(state.activeBookId));
    return;
  }
}
```

## 엣지 케이스 처리

| 케이스 | 동작 |
|---|---|
| 홀수 총페이지 (예: 9페이지) | `comicCurrentPage=7` → displayPage=8 (마지막) → 다음 권 정상 |
| 짝수 총페이지 (예: 10페이지) | `comicCurrentPage=8` → displayPage=9 (마지막) → 다음 권 정상 |
| 단일 페이지인 경우 (`totalPages=1`) | `displayPage=min(0+1,0)=0 >= 0` → 다음 권 정상 |
| LTR 2장 보기 | `isRtlTwoPage=false` → 기존 로직 그대로 동작 |
| 1장 보기 (step=1) | `isRtlTwoPage=false` → 기존 로직 그대로 동작 |
