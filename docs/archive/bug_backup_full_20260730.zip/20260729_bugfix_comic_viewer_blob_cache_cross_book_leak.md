---
title: "만화/도서 뷰어 이전 도서 Blob 캐시 교차 오염(성인도서 1페이지 노출) 버그 수정"
date: 2026-07-29
category: bugfix
tags: [viewer, blobCacheMap, cache_leak, adult_book, security]
impact: high
status: completed
---

# 버그 수정: 이전 도서 Blob 이미지 캐시 교차 노출 결함 조치

## 버그 개요
성인 도서 감상 후 뷰어를 닫고 일반 도서로 이동하여 독서할 때, 이전 성인 도서의 1페이지(또는 백그라운드 프리로드 이미지)가 일반 도서 감상 화면에 간헐적으로 노출되는 심각한 이미지 교차 오염 현상이 발생함.

## 원인 분석
- `static/js/viewer/renderer.js` 모듈 내에서 렌더링 성능 향상을 위해 `blobCacheMap` (`Map` 객체)을 사용하여 이미지 Blob URL을 저장함.
- `blobCacheMap`의 Key가 단순 페이지 인덱스 번호(`0`, `1`, `2`...)로만 관리되어 있었음.
- 도서 전환 시(`initRenderer()`) `clearBlobCache()`가 호출되지 않아 이전 도서(성인 도서)의 페이지 Blob URL이 메모리에 그대로 잔존함.
- 새 도서(일반 도서)를 열었을 때 `blobCacheMap.has(0)` 조회가 성공하여, 새 도서의 0번 페이지 대신 이전 성인 도서 0번 페이지의 Blob URL이 렌더링되는 결과가 발생함.

## 수정 사항
1. **`renderer.js` Blob 캐시 Key 구조 개선**:
   - 기존: `pageIndex` (예: `0`)
   - 변경: `${currentBookId}_${pageIndex}` (예: `book123_0`)
   - `bookId`와 결합된 고유 키를 사용하여 어떠한 경우에도 다른 도서의 캐시가 조회되지 않도록 차단.
2. **뷰어 초기화 시 캐시 보강 소거**:
   - `initRenderer(bookId, pagesRead, totalPages)` 실행 직후 `clearBlobCache()` 및 `clearComicViewer()`를 명시적으로 호출하여 이전 도서의 Blob URL을 완벽 소거(`URL.revokeObjectURL`).
3. **비동기 fetch 완료 시 Book ID 검증 강화**:
   - 비동기 로딩 및 백그라운드 프리로드 완료 시점에 현재 활성 `bookId`와 요청 당시 `bookId`를 대조하여 다른 도서로 전환된 경우 캐싱 및 DOM 반영을 즉시 중단.

## 수정 소스 파일
- `static/js/viewer/renderer.js`
- `static/js/viewer/lifecycle_controller.js`
