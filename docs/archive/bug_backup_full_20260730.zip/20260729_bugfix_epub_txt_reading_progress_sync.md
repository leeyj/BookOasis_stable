---
title: "EPUB 및 TXT 뷰어 크로스 디바이스 독서 진행도 동기화 결함 조치 (Step 2)"
date: 2026-07-29
category: bugfix
tags: [viewer, progress, sync, epub, txt, chapter, percent]
impact: high
status: completed
---

# 버그 수정: EPUB 및 TXT 뷰어 크로스 디바이스 독서 진행도 동기화 결함 조치 (Step 2)

## 버그 개요
PC <-> 모바일 간 `EPUB`, `TXT` 뷰어 열람 시 챕터 위치가 상호 일치하지 않거나, 다른 기기에서 열었을 때 마지막 챕터(또는 첫 챕터)로 튕기던 결함 조치.

## 원인 분석
1. **EPUB 챕터 인덱스 vs 퍼센트 환산 보정 오차**:
   - 백엔드는 EPUB 진행도를 0~100 퍼센트로 정규화하여 DB `pages_read`에 저장함.
   - 모바일에서 도서 진입 시 HTML 카드에 내장된 `pagesRead` 값(예: 25%)이 `initTxtViewer(bookId, initialPageIdx = 25)`로 전달됨.
   - `initTxtViewer`는 25를 챕터 번호로 오인하여, 8개 챕터로 구성된 EPUB 도서 진입 시 범위 상한(7번 챕터)에 걸려 무조건 마지막 챕터로 튕기는 버그 발생.
2. **크로스 디바이스 스크롤 포지션 오염 방지**:
   - 서버 진행도로 챕터가 전환될 때 디바이스 간 스크롤 오프셋 충돌을 보정.

## 수정 사항
1. **EPUB 퍼센트-챕터 번호 정규화 로직 추가** (`static/js/viewer_txt.js`):
   - `initialPageIdx >= totalChapters` 인 경우, `Math.round((initialPageIdx / 100) * Math.max(0, totalChapters - 1))`를 적용하여 퍼센트를 올바른 챕터 인덱스로 변환.
2. **서버 진행도(`serverEpubSession`, `serverPagesRead`) 최우선 적용** (`static/js/viewer_txt.js`):
   - 로컬스토리지 캐시보다 서버에서 수신한 최신 챕터 세션 지점을 최우선적으로 복원하도록 동기화 파이프라인 보강.

## 수정 소스 파일
- `static/js/viewer_txt.js`
