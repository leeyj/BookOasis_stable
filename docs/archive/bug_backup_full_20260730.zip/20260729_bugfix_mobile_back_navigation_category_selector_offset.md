---
title: "모바일 하단 네비게이션(뒤로가기) 키 실행 시 상단 카테고리 선택 창 이탈 결함 조치"
date: 2026-07-29
category: bugfix
tags: [mobile, popstate, navigation, viewer, category_selector, layout]
impact: high
status: completed
---

# 버그 수정: 모바일 하단 네비게이션 키(뒤로가기) 수신 시 상단 카테고리 선택 창 이탈 및 클릭 불가 결함

## 버그 개요
모바일 기기(안드로이드/iOS)에서 도서 뷰어(또는 상세 뷰) 감상 중 모바일 OS 하단 네비게이션 키(뒤로가기)를 눌렀을 때, 상단 카테고리 선택 영역(`.library-sidebar`)이 뷰포트 위쪽으로 밀려 올라가(Off-screen) 클릭이 불가능해지며 항상 새로고침(F5)을 해야 하는 현상 발생.

## 원인 분석
1. **뷰어 오버레이 body-lock 해제 미흡**:
   - 뷰어 스크롤 모드 시 터치 스크롤 튀김을 방지하기 위해 `document.body.style.position = 'fixed'` 및 `top = -scrollY` 속성이 부여됨.
   - 모바일 하단 뒤로가기 버튼(`popstate` 이벤트) 클릭 시 `closeMediaViewer()`가 직호출되면서, `iosBodyLock` 해제 및 기존 `scrollY` 스크롤 위치 복원 로직이 누락된 채 inline style만 제거됨.
2. **`popstate` 이벤트 반환 후 스크롤 복원 및 리플로우 누락**:
   - `tab_media_library.js`의 `popstate` 핸들러에서 뷰어 모달 종료 후 즉시 `return` 처리되어, 모바일 브라우저의 뷰포트 스크롤 위치 복원 및 레이아웃 리플로우(`window.scrollTo` / `resize` 이벤트)가 실행되지 않음.
   - 이로 인해 모바일 헤더/사이드바 영역(`.library-sidebar`)이 이탈된 스크롤 위치 상단에 갇혀 클릭 불가능 상태가 됨.

## 수정 사항
1. **`closeMediaViewer()` 뷰어 종료 시 body-lock 및 스크롤 복원 내실화** (`static/js/viewer/lifecycle_controller.js`):
   - `document.body` 및 `document.documentElement`에 부여된 inline 스타일(`overflow`, `position`, `top`, `width`, `height`) 완전 소거.
   - 오버레이 메뉴의 `dataset.iosBodyLock` 및 `dataset.savedBodyScrollY` 값을 읽어 기존 스크롤 위치(`window.scrollTo(0, savedScrollY)`)를 즉시 복원.
2. **`popstate` 뒤로가기 수신 시 스크롤 위치 및 레이아웃 복원 강화** (`static/js/tab_media_library.js`):
   - 뷰어 종료 후 즉시 `return`하지 않고, 저장된 목록/대시보드 스크롤 위치로 안전 복원.
   - `window.dispatchEvent(new Event('resize'))` 및 `requestAnimationFrame`을 연계하여 상단 카테고리 선택 영역(`.library-sidebar`)이 모바일 화면에 정상 바인딩 및 클릭 가능하도록 보장.

## 수정 소스 파일
- `static/js/viewer/lifecycle_controller.js`
- `static/js/tab_media_library.js`
