---
title: "PDF 뷰어 크로스 디바이스 독서 진행도 동기화 결함 조치 (Step 3)"
date: 2026-07-29
category: bugfix
tags: [viewer, progress, sync, pdf, RaceCondition]
impact: high
status: completed
---

# 버그 수정: PDF 뷰어 크로스 디바이스 독서 진행도 동기화 결함 조치 (Step 3)

## 버그 개요
PC <-> 모바일 간 `PDF` 뷰어 열람 시 진행도가 유실되거나 열람 초기화 시 1페이지로 리셋되는 결함 조치.

## 원인 분석
1. **초기화 진입 시 Race Condition 진행도 오버라이트**:
   - `initPdfViewer()`가 최신 서버 진행도(`progress-state`)를 수신받아 `pdfCurrentPage`를 구성하고 `pdfjsLib` 백그라운드 파싱을 완료하는 동안, 첫 `renderPdfPage()`가 수신 전의 구형 페이지(1페이지)를 진행도 저장 큐에 등록하여 서버 DB를 덮어씌움.
2. **`pdfTotalPages` 0-fallback 덮어쓰기 오차**:
   - PDF 문서 파싱 전에 진행도가 등록될 때 `pdfTotalPages = 0` 상태로 수신되어 `total_pages`가 1로 저장되는 오차 발생.

## 수정 사항
1. **`isInitializingPdfProgress` 초기화 Guard 적용** (`static/js/viewer_pdf.js`):
   - PDF 뷰어 진입 시 `progress-state` 비동기 수신 및 초기 `renderPdfPage()`가 완료될 때까지 `saveProgress` 호출을 억제하여 1페이지 덮어쓰기 완벽 차단.
2. **안전한 Total Pages 상태 검증** (`static/js/viewer_pdf.js`):
   - `pdfTotalPages > 0` 검증을 적용하여 `pdfjsLib` 문서 로딩이 완료된 시점에만 진행도가 반영되도록 조치.

## 수정 소스 파일
- `static/js/viewer_pdf.js`
