---
title: "도서/만화 뷰어 RTL 진행방향 키보드 및 마우스 입력 비동기화 수정"
date: 2026-07-29
category: bugfix
tags: [viewer, navigation, rtl, keyboard, epub, pdf, txt, comic]
impact: medium
status: fixed
---

# 버그 내역: 도서/만화 뷰어 RTL(오른쪽->왼쪽) 진행방향 키보드 및 마우스 입력 동기화

## 문제 현상
도서(TXT, EPUB, PDF) 및 만화(ZIP, CBZ) 뷰어에서 진행방향이 **오른쪽->왼쪽(RTL)**으로 설정되어 있을 때:
1. TXT, EPUB, PDF 뷰어에서 마우스 클릭 및 키보드 좌/우 화살표 키(`ArrowLeft`, `ArrowRight`) 조작 시 RTL 설정이 적용되지 않고 항상 일반(LTR) 방향으로 페이지가 이동하는 문제.
2. EPUB 뷰어 영역(`#epub-render-area iframe`) 포커스 시 내부 iframe에서 발생하는 `keydown` 이벤트가 상위 document로 전파되지 않아 키보드 방향키 조작이 동작하지 않는 문제.

## 원인 분석
1. **TxtViewer 및 PdfViewer의 RTL 분기 로직 누락**:
   - `ComicViewer`에는 `prevPage()` / `nextPage()`에 RTL 읽기 방향 확인 후 `nextComicPage()` / `prevComicPage()`를 교차 호출하도록 되어 있었으나, `TxtViewer`와 `PdfViewer`에는 해당 RTL 확인 및 교차 호출 로직이 누락되어 있었습니다.
2. **EPUB iframe 키보드 이벤트 미전달**:
   - EPUB content가 `#epub-render-area iframe` 내에 렌더링되어 사용자가 본문 영역을 클릭하거나 포커스할 때 발생되는 `keydown` 이벤트가 상위 parent window의 `keydown` 리스너에 전달되지 않았습니다.
3. **만화/도서 뷰어 간 읽기 방향 로직 일관성 미흡**:
   - `ComicViewer`에서 `localStorage` 직접 조회 대신 `Settings.getComicReadingDirection()` 함수를 사용하도록 일과성 강화가 필요했습니다.

## 수정 사항

1. **`static/js/viewer_txt.js`**:
   - `TxtViewer.prevPage()` 및 `TxtViewer.nextPage()` 메서드에 `getComicReadingDirection() === 'rtl'` 조건 판단 로직 추가 및 `nextTxtPage()` / `prevTxtPage()` 교차 호출 적용.
2. **`static/js/viewer_pdf.js`**:
   - `PdfViewer.prevPage()` 및 `PdfViewer.nextPage()` 메서드에 `getComicReadingDirection() === 'rtl'` 조건 판단 로직 추가 및 `nextPdfPage()` / `prevPdfPage()` 교차 호출 적용.
3. **`static/js/viewer_comic.js`**:
   - `ComicViewer`의 RTL 판단 로직을 `Settings.getComicReadingDirection()` 모듈 함수 참조로 일관화.
4. **`static/js/viewer/input_controller.js`**:
   - `handleViewerKeydown` 핸들러 추출 및 `iframe` document에 `keydown` 브릿지 바인딩 추가.

## 영향도 및 해결 사항
- 모든 미디어 형식(만화 ZIP, EPUB, TXT, PDF) 뷰어에서 진행방향 오른쪽->왼쪽(RTL) 설정 시 마우스 핫스팟 클릭 및 키보드 좌/우 방향키(`ArrowLeft`/`ArrowRight`)의 작동 동작이 부드럽고 완벽하게 동기화되었습니다.
