---
title: "만화/이미지 뷰어(ZIP, CBZ) 크로스 디바이스 독서 진행도 동기화 결함 조치 (Step 1)"
date: 2026-07-29
category: bugfix
tags: [viewer, progress, sync, zip, cbz, sendBeacon, RaceCondition]
impact: high
status: completed
---

# 버그 수정: 만화/이미지 뷰어(ZIP, CBZ) 크로스 디바이스 독서 진행도 동기화 결함 조치 (Step 1)

## 버그 개요
PC <-> 모바일 간 만화/이미지 뷰어(`ZIP`, `CBZ`, `IMGDIR`) 열람 시 독서 진행도가 상호 동기화되지 않거나 모바일 이탈 시 진행도가 유실되고, 도서 재진입 시 1페이지로 강제 리셋되는 결함 조치.

## 원인 분석
1. **모바일 이탈 시 `sendBeacon` 수신 실패**:
   - 모바일 브라우저 탭 닫기/이탈 시 `sendBeacon`으로 수신되는 `Blob(application/json)` 데이터가 Flask 백엔드(`api/stream.py`)의 `request.json` 조작 시 `None`으로 처리되어 400 Bad Request 에러를 내며 진행도가 버려짐.
2. **초기화 시 1페이지 덮어쓰기 Race Condition**:
   - 모바일 뷰어 열람 시 서버의 최신 진행도(`progress-state`) 수신 조회가 비동기로 완료되기 전에 `loadComicPage()`가 즉시 구형 0-index 페이지를 진행도 예약 큐에 등록하여 서버 DB를 1페이지로 덮어씌움.
3. **완독 도서(100%) 재열람 시 진행도 및 완독 상태 유실**:
   - 완독(`is_completed = 1`)된 책을 재열람할 때 1페이지 조회가 수신되면 `is_completed = 0` 및 `pages_read = 1`로 초기화되어 독서 완료 기록이 유실됨.

## 수정 사항
1. **`sendBeacon` 전송 패키지 파싱 보강** (`api/stream.py`):
   - `request.get_json(force=True, silent=True)` 및 `request.data` 파싱 fallback 로직을 추가하여 모바일 비콘 전송을 100% 수신/저장.
2. **초기화 진행도 Guard (`isInitializingProgress`) 연동** (`static/js/viewer/renderer.js`):
   - `initRenderer()`가 최신 `progress-state`를 비동기 수신하여 `comicCurrentPage` 배치를 마칠 때까지 `loadComicPage()` 내부의 `saveProgress()` 자동 호출을 억제하여 Race Condition 완벽 차단.
3. **기존 완독(`is_completed = 1`) 상태 보존** (`services/reading_progress_service.py`):
   - 완독 처리된 도서의 재열람 시 `old_completed == 1` 상태를 감지하여 `is_completed = 1`을 유지하도록 보호.
4. **뷰어 종료 시 동기 `flushProgress()` 트리거** (`static/js/viewer/lifecycle_controller.js`):
   - 뷰어 닫기 또는 모바일 뒤로가기 실행 시 3초 타이머 지연 없이 즉시 `flushProgress()`를 직접 호출하여 진행도 즉시 저장.

## 수정 소스 파일
- `api/stream.py`
- `services/reading_progress_service.py`
- `static/js/viewer/renderer.js`
- `static/js/viewer/lifecycle_controller.js`
