---
title: "환경설정 권한 관리 매트릭스 내 카테고리 플러그인 목록 누락 및 권한 제어 불가능 결함 조치"
date: 2026-07-30
category: bugfix
tags: [permission, category_plugin, stats_dashboard, bugfix]
impact: high
status: completed
---

# 버그 수정: 환경설정 권한 관리 매트릭스 내 카테고리 플러그인 목록 누락 결함 조치

## 버그 개요
관리자 [환경설정 ⚙️] -> [권한 관리] 탭의 권한 매트릭스 테이블에 카테고리 레벨 플러그인(예: `🧩 독서 통계 센터`)이 노출되지 않아 계정별 카테고리 접근 허용/차단을 설정할 수 없던 결함 조치.

## 원인 분석
- `api/routes/permission_routes.py`의 `get_permissions()` 라우터에서 일반 물리적 라이브러리(`libraries` 테이블) 데이터만 카테고리 목록으로 수집하고, `category_tab` 선언을 포함한 활성화된 카테고리 플러그인을 권한 매트릭스 카테고리 목록에 포함하지 않았음.

## 수정 사항
1. **`api/routes/permission_routes.py` 수정**:
   - `get_permissions()`에서 `MetadataFactory.get_available_providers()`를 통해 활성화된 카테고리 플러그인(`category_tab`) 목록을 추출하여 매트릭스 카테고리 목록에 `🧩 {title}` 형식으로 추가.
   - `settings` 테이블의 `PERM_CATEGORY_{user_id}_plugin_{id}` 키를 통해 카테고리 플러그인의 계정별 접근 허용/차단 권한을 읽어오도록 확장.
   - `update_permission()`에서 `target_db == 'plugin'` 또는 `library_id.startswith('plugin_')` 시 `settings` 테이블에 권한 설정을 원자적으로 업데이트하도록 조치.
2. **`api/library.py` 수정**:
   - `get_category_plugins_api()`에서 로그인한 일반 계정(`user_role != 'admin'`)의 경우 `PERM_CATEGORY_{user_id}_plugin_{id}` 권한 설정값이 `'0'`(차단)으로 지정되어 있으면 해당 카테고리 플러그인을 사이드바 및 카테고리 목록에서 자동 제외하도록 연동.

## 수정 소스 파일
- `api/routes/permission_routes.py`
- `api/library.py`
