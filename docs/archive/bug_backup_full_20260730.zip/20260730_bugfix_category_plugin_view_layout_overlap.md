---
title: "카테고리 레벨 플러그인 뷰 상단 검색바/필터 중복 노출 결함 조치"
date: 2026-07-30
category: bugfix
tags: [plugin, category_level, layout, view_manager]
impact: high
status: completed
---

# 버그 수정: 카테고리 레벨 플러그인 뷰 상단 검색바/필터 중복 노출 결함 조치

## 버그 개요
카테고리 레벨 플러그인(예: 독서 통계 센터) 진입 시 상단에 일반 도서 보관함용 검색바(`library-search`), 필터 버튼(`btn-open-filter`), 도서 구분 버튼 및 중복 헤더가 노출되어 플러그인 화면이 우측으로 밀리거나 가려지는 결함 조치.

## 원인 분석
- `view_manager.js`의 `switchActiveView('plugin_custom')` 처리 시, 서브 뷰 컨테이너만 전환하고 상단 공통 헤더(`.library-header`) 내부의 검색 영역(`.library-search-center`)과 컨트롤 영역(`.library-controls`)을 숨기지 않아 헤더가 그대로 노출됨.

## 수정 사항
- `static/js/view_manager.js` 내 `switchActiveView()` 개선:
  - `plugin_custom` 뷰 전환 시 `.library-header`, `.library-search-center`, `.library-controls`, `#active-filter-bar`를 자동으로 `display: none` 처리.
  - `#library-plugin-custom-view` 메인 컨테이너가 100% 가로 폭으로 풀페이지 렌더링되도록 보장.

## 수정 소스 파일
- `static/js/view_manager.js`
- `plugins/metadata/stats_dashboard/style.css`
