---
title: "MetadataFactory 클래스 헤더 중복 선언으로 인한 플러그인 로드 실패 결함 조치"
date: 2026-07-30
category: bugfix
tags: [plugin, metadata_factory, duplicate_class, bugfix]
impact: high
status: completed
---

# 버그 수정: MetadataFactory 클래스 헤더 중복 선언으로 인한 플러그인 로드 실패 결함 조치

## 버그 개요
보안 코드 반영 과정에서 `services/metadata_factory.py` 파일 내에 `class MetadataFactory:` 클래스 헤더가 중복 선언되어 이전 메서드들이 오버라이드 삭제되고 "로드된 메타데이터 플러그인이 없습니다." 문구가 노출되던 결함 조치.

## 원인 분석
- `SecurityError` 예외 클래스를 삽입하면서 `class MetadataFactory:` 구문이 중간에 한번 더 삽입됨.
- 이로 인해 `MetadataFactory` 클래스가 재정의되면서 상단에 위치한 `_import_provider_module_and_class` 등 필수 메서드가 소실되어 `AttributeError` 예외가 발생하고 플러그인 탐색이 전면 실패함.

## 수정 사항
- `services/metadata_factory.py` 수정:
  - `SecurityError` 예외 클래스를 모듈 최상단으로 이동.
  - 중복 삽입된 `class MetadataFactory:` 헤더를 제거하여 단일 클래스로 정상 복구함.

## 수정 소스 파일
- `services/metadata_factory.py`
