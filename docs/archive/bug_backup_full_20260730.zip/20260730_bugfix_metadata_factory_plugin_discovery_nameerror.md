---
title: "환경설정 플러그인 목록 조회 실패(NameError: ensure_plugin_dependencies) 결함 조치"
date: 2026-07-30
category: bugfix
tags: [plugin, metadata_factory, NameError, discovery]
impact: high
status: completed
---

# 버그 수정: 환경설정 플러그인 목록 조회 실패 결함 조치

## 버그 개요
관리자 환경설정 -> [플러그인 설정] 탭 진입 시 "로드된 메타데이터 플러그인이 없습니다." 문구만 노출되고 등록된 플러그인 목록이 표시되지 않는 결함 조치.

## 원인 분석
- `services/metadata_factory.py` 내 `_import_provider_module_and_class()` 메서드에서 `ensure_plugin_dependencies(plugin_dir)` 함수를 호출하도록 코드가 추가되었으나, **해당 헬퍼 함수 및 `_get_core_requirements()` 정의가 모듈 내에 존재하지 않아 `NameError: name 'ensure_plugin_dependencies' is not defined` 예외가 발생**함.
- 이로 인해 `_discover_provider_classes()` 순회 중 예외가 캐치되어 모든 플러그인 탐색이 실패하고 빈 배열(`[]`)이 반환됨.

## 수정 사항
- `services/metadata_factory.py` 내에 `ensure_plugin_dependencies()` 및 `_get_core_requirements()` 함수 구현을 보강하여, `requirements.txt` 의존성 자동 설치 엔진이 정상 작동하고 모든 플러그인 목록이 정상 반환되도록 조치함.

## 수정 소스 파일
- `services/metadata_factory.py`
