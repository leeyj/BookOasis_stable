---
title: "스캔 리포트 및 최근 스캔 히스토리 대시보드 무단 노출 버그 조치 (div 태그 불일치 수정)"
date: 2026-07-30
category: bugfix
tags: [html_template, div_mismatch, scan_report, dashboard, bugfix]
impact: medium
status: completed
---

# 버그 수정: 스캔 리포트 및 최근 스캔 히스토리 대시보드 무단 노출 버그 조치 (div 태그 불일치 수정)

## 버그 개요
대시보드 메인 화면(도서 보관함 - Home) 하단의 Copyright 문구 아래에 환경설정의 [스캔 리포트] 탭에 위치해야 할 '최근 스캔 히스토리' 및 스캔 리포트 섹션이 무단 노출되는 UI 결함 조치.

## 원인 분석
- `templates/components/settings/general_tab.html` 파일 307번째 줄에 불필요한 닫는 `</div>` 태그가 1개 더 존재했음.
- 이로 인해 상위의 `<div id="library-settings-view" style="display: none;">` 뷰 컨테이너가 `general_tab.html` 렌더링 직후 조기 해제/닫힘.
- 결과적으로 `general_tab.html` 뒤에 `include`된 `reports_tab.html`(`최근 스캔 히스토리` 및 `도서 스캔 에러 리포트 뷰어`)를 비롯한 후속 설정 탭들이 `display: none` 영역 밖으로 이탈하여 대시보드 메인 하단 영역에 노출됨.
- 추가로 `templates/components/tab_media_library.html` 파일 끝 부분의 `<div class="media-library-container">` 닫는 `</div>` 태그가 누락되어 있었음.

## 수정 사항
1. `templates/components/settings/general_tab.html`:
   - 307번째 줄의 여분 `</div>` 태그 1개 제거.
2. `templates/components/tab_media_library.html`:
   - 파일 맨 끝 스크립트 로드 전 누락된 `</div>` 닫는 태그 추가.
3. 자동화 태그 검증:
   - 전체 HTML 템플릿의 `div` 열기/닫기 개수 균형(Balance)을 재검증하여 mismatch 0건(PERFECT OK) 확인.

## 수정 소스 파일
- `templates/components/settings/general_tab.html`
- `templates/components/tab_media_library.html`
