---
title: "환경설정 플러그인 탭 내 풀페이지 UI 템플릿 중복 임베딩 결함 조치"
date: 2026-07-30
category: bugfix
tags: [plugin, settings, ui_embedding, bugfix]
impact: high
status: completed
---

# 버그 수정: 환경설정 플러그인 탭 내 풀페이지 UI 템플릿 중복 임베딩 결함 조치

## 버그 개요
[환경설정 ⚙️] -> [플러그인 설정] 탭 진입 시, 플러그인 관리 카드 내부에 카테고리/위젯용 풀페이지 UI 템플릿(`p.ui.html`)이 통째로 렌더링되어 설정 카드가 비정상적으로 비대해지는 결함 조치.

## 원인 분석
- `static/js/settings/plugins.js`에서 플러그인 설정 카드를 구성할 때 `p.ui.html`이 존재하면(`hasCustomUi`) 설정 폼 대신 뷰 템플릿을 카드 내부에 임베딩하도록 구현되어 있었음.

## 수정 사항
- `static/js/settings/plugins.js` 수정:
  - 환경설정 탭 카드에서는 카테고리 뷰용 UI 템플릿(`p.ui.html`)을 임베딩하지 않도록 제거.
  - 플러그인의 활성화/비활성화 토글 스위치, 스키마 설정 폼(`config_schema`) 필드 및 샘플 업데이트 버튼만 깔끔히 렌더링하도록 정돈.

## 수정 소스 파일
- `static/js/settings/plugins.js`
