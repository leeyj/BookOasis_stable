---
title: "독서 통계 센터 플러그인 상세 응답 객체 누락으로 인한 0 표기 결함 조치"
date: 2026-07-30
category: bugfix
tags: [stats_dashboard, plugin_data, bugfix]
impact: high
status: completed
---

# 버그 수정: 독서 통계 센터 플러그인 상세 응답 객체 누락으로 인한 0 표기 결함 조치

## 버그 개요
사이드바의 [📊 독서 통계 센터] 카테고리 진입 시 총 보유 도서, 총 시리즈, 월간 완독 도서, 미디어 포맷별 분석 리포트의 수치가 실제 데이터베이스 내용과 달리 전부 `0`으로 표시되는 결함 조치.

## 원인 분석
- `plugins/metadata/stats_dashboard/script.js` 프론트엔드는 `/api/media/dashboard/widgets/stats_dashboard/data` API 응답에서 `stats` 딕셔너리 객체(`total_books`, `total_series`, `month_completed_books`, `format_counts` 등)를 참조하도록 구현되어 있었음.
- 그러나 백엔드 `stats_dashboard.py`의 `get_dashboard_data()` 함수가 미니 위젯용 `items` 파라미터만 반환하고 풀페이지 뷰용 `stats` 상격 객체를 응답 JSON에 포함하지 않아 프론트엔드에서 수치가 `undefined` -> `0`으로 바인딩됨.

## 수정 사항
- `plugins/metadata/stats_dashboard/stats_dashboard.py` 수정:
  - `_fetch_stats()` 함수에 미디어 포맷별(`zip`/`cbz`, `epub`/`txt`, `pdf`) 카운트 및 주간 읽은 페이지 수 합계 집계 쿼리 추가.
  - `get_dashboard_data()` 응답 딕셔너리에 `"stats": stats` 구조체를 명시적으로 추가하여 반환하도록 조치.

## 수정 소스 파일
- `plugins/metadata/stats_dashboard/stats_dashboard.py`
