---
title: "환경설정 탭에서 카테고리 플러그인 전환 시 이전 뷰와 풀페이지 뷰가 나란히 병렬 노출되는 레이아웃 결함 조치"
date: 2026-07-30
category: bugfix
tags: [view_manager, layout, plugin_custom, bugfix]
impact: high
status: completed
---

# 버그 수정: 환경설정 탭에서 카테고리 플러그인 전환 시 뷰 병렬 노출 결함 조치

## 버그 개요
관리자 [환경설정 ⚙️] -> [플러그인 설정] 탭에 위치한 상태에서 좌측 사이드바의 카테고리 레벨 플러그인(예: `📊 독서 통계 센터`)을 클릭하여 이동할 때, 이전 환경설정 뷰(`library-settings-view`)와 신규 커스텀 플러그인 뷰(`library-plugin-custom-view`)가 숨겨지지 않고 좌우 병렬로 겹쳐서 표시되던 결함 조치.

## 원인 분석
- `static/js/view_manager.js`의 `switchActiveView()` 함수에서 ID 기반의 단일 뷰 요소들만 무조건 숨기도록 되어 있었으나, 특정 DOM 계층 상태나 조건에서 기존 뷰의 `display` 스타일 초기화가 완벽히 보장되지 않아 두 뷰가 상위 Flex 컨테이너 내에서 나란히 배치되는 현상 발생.

## 수정 사항
- `static/js/view_manager.js` 수정:
  - `switchActiveView()` 시작 시 `.library-main-content`의 헤더/필터바를 제외한 모든 자식 뷰 컨테이너 요소들을 순회하며 `style.display = 'none'`으로 일괄 강제 초기화하도록 무결성 강화.
- `templates/components/views/library_settings.html` 수정:
  - `#library-settings-view` 메인 뷰 컨테이너에 `library-view-container` 클래스를 적용하여 일관된 뷰포트 격리 보장.

## 수정 소스 파일
- `static/js/view_manager.js`
- `templates/components/views/library_settings.html`
