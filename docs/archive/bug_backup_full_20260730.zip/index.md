---
title: "버그 트러블슈팅 인덱스"
project: "BookOasis"
category: "bug"
date: 2026-06-19
tags: [bug, index]
---

# 🐛 버그 트러블슈팅 아카이브

이 디렉토리는 서비스 장애 및 기능 오류에 대응하여 처리된 문제 해결 내역서(`YYYYMMDD_bugfix_{이름}.md`)가 수납되는 공간입니다.
장애 발생 요인, 코드 영향도, 그리고 패치 조치 내역을 명세하여 향후 동일 버그의 재발을 방지합니다.

- [가상 라이브러리 필터링 오작동으로 인한 상세 뷰 단행본 미노출 조치 (2026-06-19)](./20260619_bugfix_detail_view_virtual_library_filter.md)
- [kavita.yaml 파싱 시 예외 처리 보강으로 스캐너 중단 방지 조치 (2026-06-19)](./20260619_bugfix_scanner_yaml_parser_error.md)

