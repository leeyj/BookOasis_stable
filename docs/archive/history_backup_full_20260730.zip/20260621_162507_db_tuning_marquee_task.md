---
title: Task - db_tuning_marquee
project: BookOasis
category: history
date: 2026-06-21
type: task
---
# 태스크 목록: 만화 뷰어 로딩창 지연 노출 (깜빡임 해결)

- [x] `static/js/viewer_comic.js` 내 로딩창 300ms 지연 타이머(`setTimeout`) 적용 및 갱신
- [x] 로컬 변경 사항 확인
- [x] `deploy.py` 실행하여 운영 서버(`192.168.0.20`) 배포
- [x] 만화 뷰어 페이지 넘김 시 E2E 깜빡임 개선 검증
- [x] `docs/bug/20260621_bugfix_volume_thumbnail_resize.md` 에 개선사항 기록 보완 또는 신규 이력 문서 작성
- [x] `docs/workflow.md` 업데이트 및 `python tools/collect_docs.py` 수행
