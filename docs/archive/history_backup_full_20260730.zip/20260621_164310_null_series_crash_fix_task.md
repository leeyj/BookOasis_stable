---
title: Task - null_series_crash_fix
project: BookOasis
category: history
date: 2026-06-21
type: task
---
# 태스크 목록: 스캔 에러 리포트 저장 및 환경설정 리포트 뷰어 연동

- [x] 1. 백엔드 스캔 리포트 보관 및 자동 순환 소거 기능 구현
  - `cache/reports` 디렉터리 생성 및 예외 처리
  - 스캔 중 에러(BadZipFile, 표지 누락 등) 발생 시 리포트 JSON 파일(`{library_id}_{timestamp}.json`)로 적재
  - 카테고리(Library ID)별 최대 10개 최근 리포트만 유지하고 오래된 리포트 파일을 물리 제거하는 순환 버퍼 알고리즘 추가
- [x] 2. 카테고리 삭제 시 리포트 연쇄 영구 소거 기능 구현
  - `CategoryService.delete_library` 실행 시 해당 `library_id`로 시작하는 모든 리포트 파일(`cache/reports/{library_id}_*.json`)을 물리 삭제하는 연동 구현
- [x] 3. 환경설정 리포트 조회 백엔드 API 라우터 신설
  - `/api/media/libraries/<library_id>/reports` (GET): 해당 라이브러리의 리포트 파일 목록 조회
  - `/api/media/libraries/reports/view` (GET): 지정한 특정 리포트 JSON 파일 상세 로드
- [x] 4. 환경설정 내 '스캔 리포트' 탭 마크업 및 스타일 구성
  - `templates/components/tab_media_library.html` 내에 네 번째 '스캔 리포트' 설정 탭 추가
  - `static/css/style.css` 에 리포트 리스트 및 에러 리스트 테이블 표 스타일링 적용
- [x] 5. 프론트엔드 리포트 데이터 로드 및 렌더링 스크립트 작성
  - `static/js/settings_tab.js` 에 리포트 탭 렌더링 로직 추가
  - 카테고리별 리포트 파일들을 풀다운/목록으로 선택하여 손상 도서 경로와 사유를 가이드 테이블로 출력
- [x] 6. 로컬 변경 사항 최종 E2E 검증 및 원격 홈 서버 배포 (`python deploy.py`)
- [x] 7. 완료 보고서 작성 및 문서 수집 시스템 아카이빙
