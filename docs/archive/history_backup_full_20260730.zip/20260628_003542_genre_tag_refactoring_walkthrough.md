---
title: Walkthrough - genre_tag_refactoring
project: BookOasis
category: history
date: 2026-06-28
type: walkthrough
---
# 🏁 Lazy 표지 스캐너 로그 기록 및 설정 연동 결과 보고 (Walkthrough)

Lazy 스캐너(`tools/lazy_scanner.py`) 구동 시 진행 과정에 대한 로그를 파일에 기록하고, 일반 환경설정의 `SCANNER_WRITE_LOG` 옵션 값에 따라 활성화/비활성화할 수 있도록 개선 완료했습니다.

## 🛠️ 작업 내용

### 1. Lazy 스캐너 로깅 및 설정 판별
- **대상 파일**: [tools/lazy_scanner.py](file:///c:/project/media_server/tools/lazy_scanner.py#L16-L60)
- **수정 내용**:
  - `setup_lazy_scanner_logging()` 함수를 구현하여 `media_general.db`로부터 `SCANNER_WRITE_LOG` 설정 키값을 읽어옵니다.
  - 옵션값이 `'1'`(활성)이거나 조회 실패 시: `builtins.print` 함수를 래핑하여 원래 표준 출력과 함께 프로젝트 루트의 `media_server.log` 파일에 `[%Y-%m-%d %H:%M:%S]` 형식의 타임스탬프를 부여해 기록하도록 재정의합니다.
  - 옵션값이 `'0'`(비활성)인 경우: `builtins.print` 함수를 빈 lambda 함수(`lambda *args, **kwargs: None`)로 오버라이드하여 모든 출력을 소거합니다.
  - `run_lazy_cover_extraction()` 함수 진입 시 이 로깅 설정을 즉각적으로 실행하도록 래핑했습니다.

### 2. 버그 및 문서화 관리
- **대상 파일**:
  - [docs/bug/20260622_bugfix_lazy_scan_logging.md](file:///c:/project/media_server/docs/bug/20260622_bugfix_lazy_scan_logging.md): 버그/개선 내역 및 영향도, 해결사항을 상세히 작성했습니다.
  - [docs/workflow.md](file:///c:/project/media_server/docs/workflow.md#L135): 해당 버그픽스 문서 항목 링크를 수동 반영했습니다.

---

## 🧪 검증 결과 (로컬)

1. **로그 쓰기 모드 (`SCANNER_WRITE_LOG = '1'`)**:
   - `python tools/lazy_scanner.py --book-id 999999`를 가상 ID로 기동 시, 콘솔에 정상 기동 로그가 출력되었습니다.
   - 프로젝트 루트의 `media_server.log`를 확인한 결과, 다음 로그가 타임스탬프와 함께 완벽히 기록되었음을 확인했습니다.
     ```
     [2026-06-22 21:00:44] [Lazy-Scanner] 🚀 단일 도서 즉시 스캔 격리 프로세스 기동 시작 (Book ID: 999999)
     [2026-06-22 21:00:44] [Lazy-Scanner] DB 검사 중: general
     [2026-06-22 21:00:44] [Lazy-Scanner] DB=general -> 처리 대상 도서 수: 0권
     [2026-06-22 21:00:44] [Lazy-Scanner] DB 검사 중: adult
     [2026-06-22 21:00:44] [Lazy-Scanner] DB=adult -> 처리 대상 도서 수: 0권
     [2026-06-22 21:00:44] [Lazy-Scanner] ✅ 모든 DB의 Lazy 표지 스캔 작업 완료
     ```

2. **용량 절약 로그 감춤 모드 (`SCANNER_WRITE_LOG = '0'`)**:
   - `SCANNER_WRITE_LOG` 설정을 `'0'`으로 변경한 후 동일 프로세스를 기동했을 때, 콘솔 출력이 없었으며 `media_server.log`에도 추가적인 로그가 쌓이지 않음을 무오류 검증 완료했습니다.
