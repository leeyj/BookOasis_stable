---
title: Task - genre_tag_removal
project: BookOasis
category: history
date: 2026-06-28
type: task
---
# 작업 계획 (Task)

- [x] UI 레이아웃 변경 (HTML)
  - [x] `tab_media_library.html`에서 장르/태그 트리거 버튼 영역 완전히 제거
  - [x] `tab_media_library.html`에서 드래그 가능 장르/태그 모달창 코드 완전히 제거
- [x] JavaScript 필터 관련 로직 및 바인딩 제거
  - [x] `category.js`에서 `loadGenresAndTags` 임포트 및 호출부 제거
  - [x] `tab_media_library.js`에서 `updateSidebarFilterActiveStates` 임포트 및 호출부 제거
  - [x] `genre_tag_filter.js` 파일 내용 비우기
- [x] 최종 검증 및 아카이빙
  - [x] 화면 정상 동작 검증 (배포 후)
  - [x] walkthrough.md 갱신 및 `collect_docs.py` 실행
