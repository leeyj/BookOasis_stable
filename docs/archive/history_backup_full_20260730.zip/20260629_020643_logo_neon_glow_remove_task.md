---
title: Task - logo_neon_glow_remove
project: BookOasis
category: history
date: 2026-06-29
type: task
---
# 작업 목록 (Task List)

- [x] HTML 템플릿 내 로고의 drop-shadow 필터 옵션 제거
    - [x] `templates/login.html` 내 `filter: drop-shadow(...)` 스타일 제거
    - [x] `templates/components/views/library_settings.html` 내 `filter: drop-shadow(...)` 스타일 제거 및 `border-radius: 12px;` 추가
- [x] 수동 검증 수행
    - [x] 대시보드 진입 테스트를 통한 메타 정상 전파 검증
- [x] 버그/개선 내역 문서 작성
    - [x] `docs/bug/20260629_improvement_logo_neon_glow_remove.md` 작성
    - [x] 수집기 실행
- [x] `walkthrough.md` 작성
